package com.example.myapplication.myapplication.myapplication.myapplication.historyapplication
import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val compareButton = findViewById<Button>(R.id.compareButton)
        val clearButton = findViewById<Button>(R.id.clearButton)
        val ageEditText = findViewById<EditText>(R.id.ageEditText)
        val resultTextView = findViewById<TextView>(R.id.resultTextView)

        compareButton.setOnClickListener {
            val userInput = ageEditText.text.toString()

            if (userInput.isEmpty()) {
                resultTextView.text =
                    "Please enter a valid age- it must be a whole number without decimals or text"
            } else {
                val userAge = userInput.toIntOrNull()

                if (userAge == null) {
                    resultTextView.text =
                        "Please enter a valid age - it must be a whole number without decimals or text"
                } else {
                    if (userAge < 20 || userAge > 100) {
                        resultTextView.text = "Please enter an age between 20 and 100."
                        ageEditText.text.clear()
                    } else {
                        val result = when (userAge) {
                            22 -> "Aaliyah,famous for being one of the youngest R&B singers."
                            25 -> "Tupac Shakur,one of hip hop musics greatest and most versatile artist"
                            24 -> "Christopher The Notorious B.I.G, one of the biggest hip hop rappers and gangster"
                            27 -> "Amy Winehouse, female grammy winning artist."
                            48 -> "Lee Sun Kyun, oscar winning film directors well know for the movie Parasite"
                            45 -> "Marvin Gaye , was a soul singer- songwriter with Motown in the 1960s and 1970s."
                            49 -> "Whitney Houston,female grammy winning artist, R&B singer and songwriter"
                            53 -> "George Michael, was one of the best singer-songwriter was one of the best-selling musicians of all time"
                            80 -> "Gary Wright,was an American musician and composer best known for his 1976 hit songs dream weaver and love is alive."
                            86 -> "Tom Smothers, was an American comedian, actor , composer and musician , widely known as half of the musical comedy duo the Smothers Brothers"
                            else -> "Nobody known to me is at this age"
                        }
                        resultTextView.text = result
                    }
                }
            }
        }

        clearButton.setOnClickListener {
            ageEditText.text.clear()
            resultTextView.text = ""
        }
    }
}
